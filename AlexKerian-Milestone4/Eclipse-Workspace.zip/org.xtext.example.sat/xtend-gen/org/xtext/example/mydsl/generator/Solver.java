package org.xtext.example.mydsl.generator;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.xtext.example.mydsl.generator.CNFConverter;
import org.xtext.example.mydsl.generator.DIMACSConverter;
import org.xtext.example.mydsl.sat.Expression;

@SuppressWarnings("all")
public class Solver {
  public static String executeCommand(final String command) {
    StringBuffer output = new StringBuffer();
    Process p = null;
    try {
      p = Runtime.getRuntime().exec(command);
      p.waitFor();
      InputStream _inputStream = p.getInputStream();
      InputStreamReader _inputStreamReader = new InputStreamReader(_inputStream);
      BufferedReader reader = new BufferedReader(_inputStreamReader);
      String line = "";
      while (((line = reader.readLine()) != null)) {
        output.append((line + "\n"));
      }
    } catch (final Throwable _t) {
      if (_t instanceof Exception) {
        final Exception e = (Exception)_t;
        e.printStackTrace();
      } else {
        throw Exceptions.sneakyThrow(_t);
      }
    }
    return output.toString();
  }
  
  public static void saveDimacs(final Expression e, final String pth) {
    try {
      String str = DIMACSConverter.toDIMACS(CNFConverter.CNFConvert(e));
      File _file = new File(pth);
      final PrintStream fout = new PrintStream(_file);
      fout.println(str);
      fout.close();
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public static void solveJava(final String e) {
    throw new Error("Unresolved compilation problems:"
      + "\nISolver cannot be resolved to a type."
      + "\nReader cannot be resolved to a type."
      + "\nParseFormatException cannot be resolved to a type."
      + "\nContradictionException cannot be resolved to a type."
      + "\nTimeoutException cannot be resolved to a type."
      + "\nIProblem cannot be resolved to a type."
      + "\nThe method or field SolverFactory is undefined"
      + "\nDimacsReader cannot be resolved."
      + "\nUnreachable code: The catch block can never match. It is already handled by a previous condition."
      + "\nUnreachable code: The catch block can never match. It is already handled by a previous condition."
      + "\nUnreachable code: The catch block can never match. It is already handled by a previous condition."
      + "\nnewDefault cannot be resolved"
      + "\nsetTimeout cannot be resolved"
      + "\nparseInstance cannot be resolved"
      + "\ndecode cannot be resolved"
      + "\nmodel cannot be resolved");
  }
  
  public static void solveJar(final String e) {
    String output = Solver.executeCommand(("java -jar /home/yarduoc/ENS_INFO/M1/DSL/javalibs/org.sat4j.core.jar " + e));
    InputOutput.<String>println(output);
  }
  
  public static Expression Solve_maven(final Expression e) {
    return null;
  }
}
