#include "Clause.h"

//boost::pool<> binaryClausePool(sizeof(Clause)+2*sizeof(Lit));
