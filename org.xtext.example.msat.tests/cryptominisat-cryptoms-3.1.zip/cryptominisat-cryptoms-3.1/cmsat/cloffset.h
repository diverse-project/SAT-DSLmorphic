#ifndef CLAUSEOFFSET_H
#define CLAUSEOFFSET_H

#include "constants.h"

namespace CMSat {

typedef uint32_t ClOffset;

}

#endif //CLAUSEOFFSET_H
